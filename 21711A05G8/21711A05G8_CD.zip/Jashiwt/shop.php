<?php
include 'protect.php';
?>
<?php


// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Retrieve the username from the session
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Shop</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: antiquewhite;
        }
        .navbar{
            text-align: end;
            padding-right: 50px;
            padding-top: 50px;
        }
        .container {
            max-width: 960px;
            margin: 0 auto;
            padding: 20px;
        }

        .card {
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 20px;
            display: inline-block;
            width: calc(33.33% - 20px);
            margin-right: 20px;
        }
        .card:hover{
            background-color: #c3d7db;
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .card img {
            width: 100%;
            height: 500px;
            border-bottom: 1px solid #ddd;
        }

        .card-content {
            padding: 20px;
        }

        .card-content h3 {
            margin: 0;
            font-size: 18px;
        }

        .card-content p {
            margin: 10px 0;
        }

        .card-content .price {
            font-weight: bold;
            color: #009688;
        }

        .btn {
            display: inline-block;
            padding: 8px 16px;
            margin-top: 10px;
            background-color: #009688;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #00796b;
        }

        /* Add space between buttons */
        .btn-container button {
            margin-bottom: 10px;
            margin-left: 10px;
        }

        /* Add modal styles */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1000; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Could be more or less, depending on screen size */
            border-radius: 8px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .book{
            text-align: center;
        }
    </style>
</head>
<body>
    <nav>
        <div class="navbar">
            <a href="index.php" style="color:red" class="nav-link">Home</a>&nbsp;&nbsp;
            <a href="#" style="color:red"class="nav-link">Book</a>&nbsp;&nbsp;
            <a href="contact.php" style="color:red"class="nav-link">Contact</a>&nbsp;&nbsp;
            <a href="cart.php" style="color:red" class="nav-link">Cart</a>&nbsp;&nbsp;
            <a href="logout.php" style="color:red" class="nav-link">Logout</a>

        </div>
    </nav>
    <div class="container">
        <h1 class="book">Book Shop</h1>
        <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
        <div id="product-list" class="card-container">
            <!-- Product cards will be added here dynamically -->
        </div>
    </div>

    <!-- Modal -->
    <div id="payment-modal" class="modal"></div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const products = [
                { name: 'The Great Gatsby', info: 'Classic American novel', price: 'Rs. 300', image: 'great_gatsby.jpg' },
                { name: 'To Kill a Mockingbird', info: 'Novel by Harper Lee', price: 'Rs. 250', image: 'to_kill_a_mockingbird.jpg' },
                { name: '1984', info: 'Dystopian novel by George Orwell', price: 'Rs. 220', image: '1984.jpg' },
                { name: 'Pride and Prejudice', info: 'Novel by Jane Austen', price: 'Rs. 280', image: 'pride_and_prejudice.jpg' },
                { name: 'The Catcher in the Rye', info: 'Novel by J.D. Salinger', price: 'Rs. 270', image: 'catcher_in_the_rye.jpg' },
                { name: 'Harry Potter and the Philosopher\'s Stone', info: 'Fantasy novel by J.K. Rowling', price: 'Rs. 350', image: 'harry_potter_1.jpg' },
                { name: 'The Hobbit', info: 'Fantasy novel by J.R.R. Tolkien', price: 'Rs. 290', image: 'the_hobbit.jpg' },
                { name: 'The Lord of the Rings', info: 'Fantasy novel by J.R.R. Tolkien', price: 'Rs. 400', image: 'lord_of_the_rings.jpg' },
                { name: 'The Hunger Games', info: 'Novel by Suzanne Collins', price: 'Rs. 240', image: 'hunger_games.jpg' },
                { name: 'The Da Vinci Code', info: 'Mystery-detective novel by Dan Brown', price: 'Rs. 320', image: 'da_vinci_code.jpg' },
                { name: 'The Alchemist', info: 'Novel by Paulo Coelho', price: 'Rs. 210', image: 'alchemist.jpg' },
                { name: 'The Girl with the Dragon Tattoo', info: 'Crime novel by Stieg Larsson', price: 'Rs. 290', image: 'girl_with_dragon_tattoo.jpg' },
                { name: 'The Kite Runner', info: 'Novel by Khaled Hosseini', price: 'Rs. 260', image: 'kite_runner.jpg' },
                { name: 'The Road', info: 'Novel by Cormac McCarthy', price: 'Rs. 270', image: 'the_road.jpg' },
                { name: 'The Book Thief', info: 'Novel by Markus Zusak', price: 'Rs. 280', image: 'the_book_thief.jpg' },
                { name: 'The Chronicles of Narnia', info: 'Fantasy series by C.S. Lewis', price: 'Rs. 380', image: 'narnia.jpg' },
                { name: 'The Maze Runner', info: 'Dystopian novel by James Dashner', price: 'Rs. 250', image: 'maze_runner.jpg' },
                { name: 'The Girl on the Train', info: 'Thriller novel by Paula Hawkins', price: 'Rs. 270', image: 'girl_on_the_train.jpg' },
                // Add more products here
            ];

            const productList = document.getElementById('product-list');

            function showPaymentModal(product) {
                const modal = document.getElementById('payment-modal');
                modal.innerHTML = `
                <div class="modal-content">
                    <span class="close">&times;</span>
                    <h2>Enter Payment Details</h2>
                    <form id="payment-form">
                        <label for="card-number">Card Number:</label>
                        <input type="text" id="card-number" pattern="[0-9]{16}" maxlength="16" placeholder="Enter 16-digit card number" required>
                        <label for="expiry-date">Expiration Date (MM/YY):</label>
                        <input type="text" id="expiry-date" pattern="^(0[1-9]|1[0-2])\/?([0-9]{2})$" placeholder="MM/YY" required>
                        <label for="cvv">CVV:</label>
                        <input type="text" id="cvv" pattern="[0-9]{3}" maxlength="3" placeholder="Enter 3-digit CVV" required>
                        <button type="submit" class="btn">Pay Now</button>
                    </form>
                </div>
                `;
                modal.style.display = "block";

                const closeModal = modal.querySelector('.close');
                closeModal.addEventListener('click', () => {
                    modal.style.display = "none";
                });

                const paymentForm = modal.querySelector('#payment-form');
                paymentForm.addEventListener('submit', (event) => {
                    event.preventDefault();
                    const cardNumber = paymentForm.querySelector('#card-number').value;
                    const expiryDate = paymentForm.querySelector('#expiry-date').value;
                    const cvv = paymentForm.querySelector('#cvv').value;

                    // Handle payment process (you can add your logic here)
                    console.log('Processing payment for:', product.name);
                    // Once payment is processed, you can redirect to a thank you page or close the modal
                    modal.style.display = "none";
                    confirmOrder();
                });

                function confirmOrder() {
                    alert('Your order has been confirmed!');
                }
            }

            products.forEach(product => {
                const card = document.createElement('div');
                card.classList.add('card');

                const image = document.createElement('img');
                image.src = product.image;
                card.appendChild(image);

                const cardContent = document.createElement('div');
                cardContent.classList.add('card-content');

                const productName = document.createElement('h3');
                productName.textContent = product.name;
                cardContent.appendChild(productName);

                const info = document.createElement('p');
                info.textContent = product.info;
                cardContent.appendChild(info);

                const price = document.createElement('p');
                price.classList.add('price');
                price.textContent = 'Price: ' + product.price;
                cardContent.appendChild(price);

                const btnContainer = document.createElement('div');
                btnContainer.classList.add('btn-container');

                const addToCartBtn = document.createElement('button');
                addToCartBtn.textContent = 'Add to Cart';
                addToCartBtn.classList.add('btn');
                addToCartBtn.addEventListener('click', () => {
                    // Add to cart functionality here
                    addToCart(product);
                });
                btnContainer.appendChild(addToCartBtn);

                const buyNowBtn = document.createElement('button');
                buyNowBtn.textContent = 'Buy Now';
                buyNowBtn.classList.add('btn');
                buyNowBtn.addEventListener('click', () => {
                    // Buy now functionality here
                    showPaymentModal(product);
                });
                btnContainer.appendChild(buyNowBtn);

                cardContent.appendChild(btnContainer);

                card.appendChild(cardContent);
                productList.appendChild(card);
            });

            function addToCart(product) {
                let cart = JSON.parse(localStorage.getItem('cart')) || [];
                const existingProduct = cart.find(item => item.name === product.name && item.price === product.price); // Check for name and price match

                if (existingProduct) {
                    alert('This product is already in your cart!');
                } else {
                    cart.push(product);
                    localStorage.setItem('cart', JSON.stringify(cart));
                    window.location.href = 'cart.php'; // Redirect to cart page
                }
            }
        });
    </script>
</body>
</html>
