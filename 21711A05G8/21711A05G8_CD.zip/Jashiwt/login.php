
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Book Store - Login</title>
  <style>
    body {
      background-image: url("Login_bg.jpg");
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      flex-direction: column;
    }

    .form-container {
      width: 300px;
      padding: 20px;
      border-radius: 5px;
      text-align: center;
      background-color: rgba(255, 255, 255, 0.8);
      margin: 10px;
    }

    .form-container label {
      display: block;
      margin-bottom: 10px;
    }

    .form-container input[type="email"],
    .form-container input[type="password"] {
      width: 80%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 3px;
      margin-bottom: 20px;
    }

    .form-container button {
      background-color: #4CAF50;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .form-container button:hover {
      background-color: #3e8e41;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
    }

    .toggle-link {
      color: #4CAF50;
      cursor: pointer;
      text-decoration: underline;
      margin-top: 10px;
    }

    .error-message {
      color: #c0392b;
      font-weight: bold;
      margin-top: 10px;
      display: none;
    }

    header {
      position: absolute;
      top: 20px;
      text-align: center;
      width: 100%;
      color: white;
      text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
    }
  </style>
</head>
<body>
  <header>
    <h1>Jashi Book Store</h1>
  </header>
  
  <main>
    <section id="login-section" class="form-container">
      <h2>Login</h2>
      <form id="login-form" action="logindb.php" method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <button type="submit">Login</button>
      </form>
      <p class="error-message" id="login-error"></p>
      <p class="toggle-link" onclick="showSignUp()">Don't have an account? Sign Up</p>
    </section>

    <section id="signup-section" class="form-container" style="display: none;">
      <h2>Sign Up</h2>
      <form id="signup-form" action="signup.php" method="post">
        <label for="signup-email">Email:</label>
        <input type="email" id="signup-email" name="email" required>
        <label for="signup-password">Password:</label>
        <input type="password" id="signup-password" name="password" required>
        <button type="submit">Sign Up</button>
      </form>
      <p class="error-message" id="signup-error"></p>
      <p class="toggle-link" onclick="showLogin()">Already have an account? Login</p>
    </section>
  </main>

  <script>
    function showSignUp() {
      document.getElementById('login-section').style.display = 'none';
      document.getElementById('signup-section').style.display = 'block';
    }

    function showLogin() {
      document.getElementById('login-section').style.display = 'block';
      document.getElementById('signup-section').style.display = 'none';
    }

    <?php if (isset($_GET['error'])): ?>
    document.getElementById('login-error').textContent = "<?php echo $_GET['error']; ?>";
    document.getElementById('login-error').style.display = 'block';
    <?php endif; ?>
  </script>
</body>
</html>
