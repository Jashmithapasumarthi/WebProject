<?php
include 'protect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - Your Bookstore Name</title>
  <style>
    body, html {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-image: url('about-bg2.jpeg');
      background-size: cover;
      background-position: center;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
      background-color: black(255, 255, 255, 0.8); /* Adding a semi-transparent white background to improve readability */
    }

    header {
      padding: 40px 0;
      text-align: center;
      color: #fff;
    }

    .header-links {
      margin-bottom: 20px;
    }

    .header-links a {
      color: white; /* Changed color to black */
      text-decoration: none;
      margin: 0 10px;
    }

    header h1 {
      font-size: 36px;
    }

    header h1 span {
      color: #ff6600;
    }

    .content {
      margin-top: 20px;
      color: #fff;
    }

    .content p {
      font-size: 18px;
      line-height: 1.6;
    }

    .content p span {
      font-weight: bold;
    }

    .button {
      display: inline-block;
      padding: 10px 20px;
      background-color: #ff6600;
      color: #fff;
      text-decoration: none;
      border-radius: 5px;
      margin-top: 20px;
      transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .button:hover {
      background-color: #cc5500;
      transform: scale(1.1);
    }

    .button:active {
      transform: scale(0.9);
    }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div class="header-links">
       
        <a href="index.php" class="nav-link">Home</a>&nbsp;&nbsp;
        <a href="shop.php" class="nav-link">Book</a>&nbsp;&nbsp;
        <a href="contact.php" class="nav-link">Contact</a>&nbsp;&nbsp;
        <a href="cart.php" class="nav-link">Cart</a>&nbsp;&nbsp;
        <a href="logout.php" class="nav-link">Logout</a>&nbsp;&nbsp;

      </div>
      <h1>About <span>our Bookstore </span></h1>
    </header>
    <div class="content">
      <p>At our Bookstore Name, we believe in the power of stories to inspire, educate, and entertain. Since <span>Year Established</span>, we have been dedicated to providing book lovers with a diverse selection of titles across all genres.</p>
      <p>Our mission is to foster a love of reading and create a community of passionate readers. Whether you're seeking a classic novel, the latest bestseller, or a hidden gem, we're here to help you find your next favorite book.</p>
      <p>Thank you for supporting independent bookstores and joining us on this literary journey.</p>
      <a href="shop.php" class="button">Shop Now</a>
    </div>
  </div>
</body>
</html>
