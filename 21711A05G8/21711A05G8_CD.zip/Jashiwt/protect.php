<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    echo "Not logged in. Redirecting...";
    header("Location: signup.html");
    exit;
}
//  else {
//     echo "Logged in as: " . $_SESSION['username'];
// }
?>