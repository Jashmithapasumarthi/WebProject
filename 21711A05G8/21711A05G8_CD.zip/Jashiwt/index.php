

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Book Store</title>
  <link rel="stylesheet" href="style.css">
  <style>
    footer {
      text-align: center;
      background-color: #f8f8f8;
      padding: 10px 0;
    }

    footer p {
      color: #333; /* Color for the footer text */
      margin: 0; /* Remove default margin */
    }
  </style>
</head>
<body>
  <header>
    <h1>Jashi Book Store</h1>
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <?php if (isset($_SESSION['user'])): ?>
          <li><a href="logout.php">Logout</a></li>
          <li><a href="shop.php">Shop</a></li>
          <li><a href="cart.php">Cart</a></li>
        <?php else: ?>
          <li><a href="login.php">Login</a></li>
        <?php endif; ?>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="about.php">About</a></li>
      </ul>
    </nav>
  </header>
  <main>
    <section id="welcome">
      <div>
        <h2>Welcome to the best book store online!</h2>
        <p>Find a wide variety of books to improve your knowledge.</p>
      </div>
    </section>
    <section id="shop">
      <div class="div1">
        <h2>Shop Now</h2>
        <p class="p1">Click below to browse our collection!</p>
        <?php if (isset($_SESSION['user'])): ?>
          <a href="shop.php">See Books</a>
        <?php else: ?>
          <a href="signup.html">See Books</a>
        <?php endif; ?>
      </div>
    </section>
  </main>
  <footer>
    <p>&copy; My Book Store 2024</p>
  </footer>
  <script src="script.js"></script>
</body>
</html>
