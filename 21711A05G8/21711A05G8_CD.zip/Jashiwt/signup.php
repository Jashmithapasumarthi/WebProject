<?php
session_start();
include 'db.php'; // Includes the database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $username = $_POST['username']; // Retrieve username from the form
    $email = $_POST['email'];
    $password = $_POST['password']; // Store plain text password (not recommended)

    // Prepare and bind the SQL statement
    $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("sss", $username, $email, $password);

        if ($stmt->execute()) {
            $_SESSION['user'] = $username;
            header('Location: login.php');
            exit();
        } else {
            header('Location: login.php?error=Could%20not%20create%20account');
            exit();
        }
    } else {
        header('Location: login.php?error=Could%20not%20prepare%20statement');
        exit();
    }
}
?>
