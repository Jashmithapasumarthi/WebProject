<?php
include 'protect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: antiquewhite;
        }
        .navbar {
            text-align: end;
            padding-right: 50px;
            padding-top: 10px;
        }

        .container {
            max-width: 960px;
            margin: 0 auto;
            padding: 20px;
        }

        .cart-item {
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 20px;
            padding: 10px;
            background-color: #fff;
            transition: transform 0.3s ease-in-out;
        }

        .cart-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .cart-item img {
            width: 100px;
            height: auto;
            margin-right: 20px;
            transition: transform 0.3s ease-in-out;
        }

        .cart-item:hover img {
            transform: scale(1.1);
        }

        .cart-item-details {
            display: inline-block;
            vertical-align: top;
        }

        .remove-btn {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .remove-btn:hover {
            background-color: #b18080;
        }

        .buynow-btn {
            background-color: #7fe067;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
            margin-left: 10px;
        }

        .buynow-btn:hover {
            background-color: #859769;
        }

        .back-to-shop-btn {
            background-color: #009688;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease-in-out;
            display: inline-block;
        }

        .back-to-shop-btn:hover {
            background-color: #00796b;
        }

        /* Modal styles */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1000; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Could be more or less, depending on screen size */
            border-radius: 8px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <nav>
        <div class="navbar">
            <a href="index.php" class="nav-link">Home</a>&nbsp;&nbsp;
            <a href="shop.php" class="nav-link">Book</a>&nbsp;&nbsp;
            <a href="contact.php" class="nav-link">Contact</a>&nbsp;&nbsp;
            <a href="#" class="nav-link">Cart</a>&nbsp;&nbsp;
            <a href="about.php" class="nav-link">About</a>&nbsp;&nbsp;
        </div>
    </nav>
    <div class="container">
        <h1>Shopping Cart</h1>
        <div id="cart-items"></div>
        <a href="shop.php" class="back-to-shop-btn">Back to Shop</a>
    </div>

    <!-- Payment Modal -->
    <div id="payment-modal" class="modal"></div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const cartItemsContainer = document.getElementById('cart-items');
            let cart = JSON.parse(localStorage.getItem('cart')) || [];

            function renderCart() {
                cartItemsContainer.innerHTML = '';
                cart.forEach(item => {
                    const cartItem = document.createElement('div');
                    cartItem.classList.add('cart-item');

                    const itemImage = document.createElement('img');
                    itemImage.src = item.image;
                    cartItem.appendChild(itemImage);

                    const itemDetails = document.createElement('div');
                    itemDetails.classList.add('cart-item-details');

                    const itemName = document.createElement('h3');
                    itemName.textContent = item.name;
                    itemDetails.appendChild(itemName);

                    const itemPrice = document.createElement('p');
                    itemPrice.textContent = 'Price: ' + item.price;
                    itemDetails.appendChild(itemPrice);

                    const removeBtn = document.createElement('button');
                    removeBtn.textContent = 'Remove';
                    removeBtn.classList.add('remove-btn');
                    removeBtn.addEventListener('click', () => {
                        removeFromCart(item);
                    });
                    itemDetails.appendChild(removeBtn);

                    const buyNowBtn = document.createElement('button');
                    buyNowBtn.textContent = 'Buy Now';
                    buyNowBtn.classList.add('buynow-btn');
                    buyNowBtn.addEventListener('click', () => {
                        showPaymentModal(item);
                    });
                    itemDetails.appendChild(buyNowBtn);

                    cartItem.appendChild(itemDetails);
                    cartItemsContainer.appendChild(cartItem);
                });
            }

            function addToCart(product) {
                const isAlreadyInCart = cart.some(item => item.name === product.name && item.price === product.price);
                if (isAlreadyInCart) {
                    alert('Item already added to cart!');
                } else {
                    cart.push(product);
                    localStorage.setItem('cart', JSON.stringify(cart));
                    renderCart();
                }
            }

            function removeFromCart(product) {
                cart = cart.filter(item => item !== product);
                localStorage.setItem('cart', JSON.stringify(cart));
                renderCart();
            }

            function showPaymentModal(product) {
                const modal = document.getElementById('payment-modal');
                modal.innerHTML = `
                    <div class="modal-content">
                        <span class="close">&times;</span>
                        <h2>Payment for ${product.name}</h2>
                        <p>Price: ${product.price}</p>
                        <form id="payment-form" action="process_payment.php" method="POST">
                            <input type="hidden" name="product_name" value="${product.name}">
                            <input type="hidden" name="product_price" value="${product.price}">
                            <label for="card_number">Card Number:</label>
                            <input type="text" id="card_number" name="card_number" required><br><br>
                            <label for="expiry_date">Expiry Date:</label>
                            <input type="text" id="expiry_date" name="expiry_date" required><br><br>
                            <label for="cvv">CVV:</label>
                            <input type="text" id="cvv" name="cvv" required><br><br>
                            <button type="submit">Pay Now</button>
                        </form>
                    </div>
                `;

                const closeModalBtn = modal.querySelector('.close');
                closeModalBtn.onclick = function () {
                    modal.style.display = 'none';
                };

                modal.style.display = 'block';

                const paymentForm = document.getElementById('payment-form');
                paymentForm.onsubmit = function (e) {
                    e.preventDefault();
                    // Here you can add code to handle the payment process (AJAX, form submission, etc.)
                    alert('Payment successful!');
                    modal.style.display = 'none';
                };
            }

            renderCart();
        });
    </script>
</body>
</html>
