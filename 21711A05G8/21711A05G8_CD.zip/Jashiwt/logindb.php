<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Retrieve the user from the database
    $sql = "SELECT * FROM users WHERE email = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // User found, set session and redirect to shop page
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username']; // Store username in session
        $_SESSION['loggedin']=true;
        header('Location: shop.php');
        exit();
    } else {
        // No user found or incorrect password, redirect back to login page with error message
        header('Location: login.php?error=Invalid email or password.');
        exit();
    }
}
?>
