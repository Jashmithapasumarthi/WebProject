<?php
include 'config.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare SQL statement to insert form data into database
$stmt = $conn->prepare("INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $message);

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Execute SQL statement
if ($stmt->execute()) {
    // Redirect back to contact page with success message
    header('Location: contact.php?success=Form submitted successfully!');
    exit();
} else {
    // Redirect back to contact page with error message
    header('Location: contact.php?error=' . $stmt->error);
    exit();
}

// Close statement and database connection
$stmt->close();
$conn->close();
?>
